# Flight-Management-system
 Spring Boot+Angular web full stack application for flight booking and Management
 
 # YOUTUBE:https://www.youtube.com/channel/UCw76QlqKmpIEHQeaVFgyDtQ/featured
 # VERSION 1.0 -LACKS Seatmap/Test-cases/Api_Gateway+Angular connectivity 
