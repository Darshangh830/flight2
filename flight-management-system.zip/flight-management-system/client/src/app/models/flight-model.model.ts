export class FlightModel {
    constructor(
       public flight_id:number, 
       )
         {}
}
