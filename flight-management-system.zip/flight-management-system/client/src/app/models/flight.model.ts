export class Flight {
    departure_location?:String;
    arrival_location?:string;
   //flight?:Array<{flight_id:number ,flight_number:number,departure_time:string, arrival_time:string}>;
    
}
