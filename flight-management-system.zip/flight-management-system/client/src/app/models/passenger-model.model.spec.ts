import { PassengerModel } from './passenger-model.model';

describe('PassengerModel', () => {
  it('should create an instance', () => {
    expect(new PassengerModel()).toBeTruthy();
  });
});
